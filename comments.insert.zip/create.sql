-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema ssdi_project
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema ssdi_project
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `ssdi_project` DEFAULT CHARACTER SET utf8 ;
USE `ssdi_project` ;

-- -----------------------------------------------------
-- Table `ssdi_project`.`comments`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`comments` (
  `post_id` INT(11) NOT NULL,
  `u_id` INT(11) NOT NULL,
  `comment_t` VARCHAR(1000) NULL DEFAULT NULL,
  `c_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`, `u_id`, `c_date`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`groups`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`groups` (
  `g_id` INT(11) NOT NULL AUTO_INCREMENT,
  `g_name` VARCHAR(60) NULL DEFAULT NULL,
  `g_description` VARCHAR(500) NULL DEFAULT NULL,
  `g_group_members` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`g_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`users`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`users` (
  `u_id` INT(11) NOT NULL AUTO_INCREMENT,
  `u_emailid` VARCHAR(60) NULL DEFAULT NULL,
  `u_password` VARCHAR(60) NULL DEFAULT NULL,
  `u_Name` VARCHAR(40) NULL DEFAULT NULL,
  PRIMARY KEY (`u_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 8
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`group_user_relationship`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`group_user_relationship` (
  `g_id` INT(11) NOT NULL,
  `u_id` INT(11) NOT NULL,
  PRIMARY KEY (`g_id`, `u_id`),
  INDEX `u_id` (`u_id` ASC),
  CONSTRAINT `group_user_relationship_ibfk_1`
    FOREIGN KEY (`g_id`)
    REFERENCES `ssdi_project`.`groups` (`g_id`),
  CONSTRAINT `group_user_relationship_ibfk_2`
    FOREIGN KEY (`u_id`)
    REFERENCES `ssdi_project`.`users` (`u_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`likes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`likes` (
  `like_id` INT(11) NOT NULL AUTO_INCREMENT,
  `u_id` INT(11) NULL DEFAULT NULL,
  `post_id` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`like_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`pic`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`pic` (
  `idpic` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `caption` VARCHAR(45) NOT NULL,
  `img` LONGBLOB NOT NULL,
  PRIMARY KEY (`idpic`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`posts`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`posts` (
  `post_id` INT(11) NOT NULL AUTO_INCREMENT,
  `post` VARCHAR(10000) NULL DEFAULT NULL,
  PRIMARY KEY (`post_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 19
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`post_user_group_relationship`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`post_user_group_relationship` (
  `u_id` INT(11) NULL DEFAULT NULL,
  `g_id` INT(11) NULL DEFAULT NULL,
  `p_id` INT(11) NULL DEFAULT NULL,
  INDEX `u_id_idx` (`u_id` ASC),
  INDEX `g_id_idx` (`g_id` ASC),
  INDEX `p_id_idx` (`p_id` ASC),
  CONSTRAINT `g_id`
    FOREIGN KEY (`g_id`)
    REFERENCES `ssdi_project`.`groups` (`g_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `p_id`
    FOREIGN KEY (`p_id`)
    REFERENCES `ssdi_project`.`posts` (`post_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `u_id`
    FOREIGN KEY (`u_id`)
    REFERENCES `ssdi_project`.`users` (`u_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`post_user_relationship`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`post_user_relationship` (
  `post_id` INT(11) NOT NULL,
  `u_id` INT(11) NOT NULL,
  PRIMARY KEY (`post_id`, `u_id`),
  INDEX `u_id` (`u_id` ASC),
  CONSTRAINT `post_user_relationship_ibfk_1`
    FOREIGN KEY (`post_id`)
    REFERENCES `ssdi_project`.`posts` (`post_id`),
  CONSTRAINT `post_user_relationship_ibfk_2`
    FOREIGN KEY (`u_id`)
    REFERENCES `ssdi_project`.`users` (`u_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`roles`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`roles` (
  `role_id` INT(11) NOT NULL,
  `role_name` VARCHAR(10) NULL DEFAULT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `ssdi_project`.`role_user_relationship`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `ssdi_project`.`role_user_relationship` (
  `role_id` INT(11) NOT NULL,
  `u_id` INT(11) NOT NULL,
  PRIMARY KEY (`role_id`, `u_id`),
  INDEX `u_id` (`u_id` ASC),
  CONSTRAINT `role_user_relationship_ibfk_1`
    FOREIGN KEY (`role_id`)
    REFERENCES `ssdi_project`.`roles` (`role_id`),
  CONSTRAINT `role_user_relationship_ibfk_2`
    FOREIGN KEY (`u_id`)
    REFERENCES `ssdi_project`.`users` (`u_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

USE `ssdi_project` ;

-- -----------------------------------------------------
-- procedure Delete_Group1
-- -----------------------------------------------------

DELIMITER $$
USE `ssdi_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Delete_Group1`(IN group_id int, OUT the_count INT)
BEGIN
	Delete from post_user_group_relationship where g_id = group_id;
    
    Delete from group_user_relationship
    where g_id = group_id;
                
	Delete from groups
    where g_id = group_id;
                
	select count(*) INTO the_count from groups
    where g_id = group_id;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure Delete_User_Post
-- -----------------------------------------------------

DELIMITER $$
USE `ssdi_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Delete_User_Post`(IN input_post_id INT, OUT theCount INT)
BEGIN
	delete from post_user_relationship where post_id = input_post_id;
	delete from post_user_group_relationship where p_id = input_post_id;
	delete from posts where post_id = input_post_id;
	select count(post_id) into theCount from posts where post_id = input_post_id;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure Insert_Post
-- -----------------------------------------------------

DELIMITER $$
USE `ssdi_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Insert_Post`(IN email_ID varchar(60), IN group_name varchar(60), IN post_text varchar(10000), OUT theCount INT)
BEGIN
	insert into posts(post) values(post_text);
    
    select @post_id := post_id from posts where post = post_text;
    select @group_id := g_id from groups where g_name = group_name;
    select @user_id := u_id from users where u_emailid = email_ID;
    
    insert into post_user_relationship(post_id,u_id) values(@post_id,@user_id);
    
    insert into post_user_group_relationship(u_id,g_id,p_id) values(@user_id, @group_id, @post_id);
    
    select count(*) into theCount from post_user_group_relationship
    where u_id = @user_id and g_id = @group_id and p_id = @post_id;
    
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure Insert_or_Delete
-- -----------------------------------------------------

DELIMITER $$
USE `ssdi_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Insert_or_Delete`(In role_name varchar(10),IN email_ID varchar(60), In input_Post_id INT, OUT theCount INT)
BEGIN
	select @user_id := u_id from users where u_emailid = email_ID;
	if (role_name = 'admin') then
		delete from post_user_group_relationship where p_id = input_post_id;
        delete from post_user_relationship where post_id = input_post_id;
        delete from likes where post_id = input_post_id;
        delete from comments where post_id = input_post_id;
        delete from posts where post_id = input_post_id;
        select count(post_id) into theCount from posts where post_id = input_post_id; 
    else
		Insert into likes(post_id,u_id) values (input_post_id,@user_id);
        select count(*) into theCount from likes where u_id = @user_id and post_id = input_post_id; 
	end if;
END$$

DELIMITER ;

-- -----------------------------------------------------
-- procedure Join_Group
-- -----------------------------------------------------

DELIMITER $$
USE `ssdi_project`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `Join_Group`(IN input_group varchar(60), IN input_email varchar(60), Out theCount INT)
BEGIN
	select @user_id := u_id from users where u_emailid = input_email;
    select @group_members := g_group_members from groups where g_name = input_group;
    select @group_id := g_id from groups where g_name = input_group;
    select @current_group := count(g_id) from group_user_relationship where g_id = @group_id;
	if (@group_members > @current_group) then
		insert into group_user_relationship values(@group_id,@user_id);
        SET theCount = 1;
    else
		SET theCount = 0; 
	end if;
END$$

DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
