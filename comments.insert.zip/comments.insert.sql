/*
-- Query: SELECT * FROM ssdi_project.comments
LIMIT 0, 1000

-- Date: 2017-04-26 13:32
*/
INSERT INTO `comments` (`post_id`,`u_id`,`comment_t`,`c_date`) VALUES (15,1,'the next comment','2017-04-25 21:04:46');
INSERT INTO `comments` (`post_id`,`u_id`,`comment_t`,`c_date`) VALUES (15,1,'skjdbgfajld.','2017-04-25 21:04:50');
INSERT INTO `comments` (`post_id`,`u_id`,`comment_t`,`c_date`) VALUES (17,2,'My first comment','2017-04-25 23:23:03');
INSERT INTO `comments` (`post_id`,`u_id`,`comment_t`,`c_date`) VALUES (17,2,'please do the second comment','2017-04-25 23:23:14');
