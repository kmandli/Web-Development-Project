/*
-- Query: SELECT * FROM ssdi_project.groups
LIMIT 0, 1000

-- Date: 2017-04-26 13:40
*/
INSERT INTO `groups` (`g_id`,`g_name`,`g_description`,`g_group_members`) VALUES (3,'Uncc_49ers','UNCC Students Group',10);
INSERT INTO `groups` (`g_id`,`g_name`,`g_description`,`g_group_members`) VALUES (4,'Laser Tag Corps','Laser tag group,We play every Wed and Sunday at 5pm,Come Join us',10);
INSERT INTO `groups` (`g_id`,`g_name`,`g_description`,`g_group_members`) VALUES (5,'Charlotte Milestones','It facilitates the diffferent locations in charlotte to visit',10);
INSERT INTO `groups` (`g_id`,`g_name`,`g_description`,`g_group_members`) VALUES (6,'Charlotte eateries','It includes posts for best eateries in charlotte',10);
INSERT INTO `groups` (`g_id`,`g_name`,`g_description`,`g_group_members`) VALUES (7,'Uptown Scenes','I want to create an uptown scenes group',10);
INSERT INTO `groups` (`g_id`,`g_name`,`g_description`,`g_group_members`) VALUES (8,'Uncc_activated','i have created this group now',10);
