/*
-- Query: SELECT * FROM ssdi_project.posts
LIMIT 0, 1000

-- Date: 2017-04-26 13:40
*/
INSERT INTO `posts` (`post_id`,`post`) VALUES (1,'I am at Uncc_49ers CAB Event. Awesome!!!! Having Fun!!!!!');
INSERT INTO `posts` (`post_id`,`post`) VALUES (5,'type something to post please');
INSERT INTO `posts` (`post_id`,`post`) VALUES (6,'Type the post and see the magic');
INSERT INTO `posts` (`post_id`,`post`) VALUES (7,'Type the post and see the magic unfold');
INSERT INTO `posts` (`post_id`,`post`) VALUES (15,'Hi I am at Student Union');
INSERT INTO `posts` (`post_id`,`post`) VALUES (16,'The first post in Laser Tag Corps');
INSERT INTO `posts` (`post_id`,`post`) VALUES (17,'I am at Uncc_49ers and I am enjoying at student union eation lemonade');
INSERT INTO `posts` (`post_id`,`post`) VALUES (18,'hi i am the new joinee');
